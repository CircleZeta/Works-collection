package com.example.healthplatform.ui

import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.healthplatform.common.AppContainer
import com.example.healthplatform.presentation.advice.AdviceScreen
import com.example.healthplatform.presentation.advice.AdviceViewModel
import com.example.healthplatform.presentation.advice.AdviceViewModelFactory
import com.example.healthplatform.presentation.dashboard.DashboardScreen
import com.example.healthplatform.presentation.dashboard.DashboardViewModel
import com.example.healthplatform.presentation.dashboard.DashboardViewModelFactory
import com.example.healthplatform.presentation.navigation.Screen
import com.example.healthplatform.presentation.navigation.bottomNavScreens
import com.example.healthplatform.presentation.settings.SettingsScreen
import com.example.healthplatform.presentation.trends.TrendsScreen
import com.example.healthplatform.presentation.trends.TrendsViewModel
import com.example.healthplatform.presentation.trends.TrendsViewModelFactory

@Composable
fun HealthPlatformApp(appContainer: AppContainer) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                bottomNavScreens.forEach { screen ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(Screen.Dashboard.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Text(screen.title.take(1)) },
                        label = {
                            Text(
                                text = screen.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route
        ) {
            composable(Screen.Dashboard.route) {
                val dashboardViewModel: DashboardViewModel = viewModel(
                    factory = DashboardViewModelFactory(
                        getDashboardSummaryUseCase = appContainer.getDashboardSummaryUseCase
                    )
                )
                DashboardScreen(
                    contentPadding = innerPadding,
                    viewModel = dashboardViewModel
                )
            }
            composable(Screen.Trends.route) {
                val trendsViewModel: TrendsViewModel = viewModel(
                    factory = TrendsViewModelFactory(
                        getTrendDataUseCase = appContainer.getTrendDataUseCase
                    )
                )
                TrendsScreen(
                    contentPadding = innerPadding,
                    viewModel = trendsViewModel
                )
            }
            composable(Screen.Advice.route) {
                val adviceViewModel: AdviceViewModel = viewModel(
                    factory = AdviceViewModelFactory(
                        generateSuggestionsUseCase = appContainer.generateSuggestionsUseCase,
                        importMockDataUseCase = appContainer.importMockDataUseCase,
                        suggestionRepository = appContainer.suggestionRepository
                    )
                )
                AdviceScreen(
                    contentPadding = innerPadding,
                    viewModel = adviceViewModel
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(contentPadding = innerPadding)
            }
        }
    }
}
