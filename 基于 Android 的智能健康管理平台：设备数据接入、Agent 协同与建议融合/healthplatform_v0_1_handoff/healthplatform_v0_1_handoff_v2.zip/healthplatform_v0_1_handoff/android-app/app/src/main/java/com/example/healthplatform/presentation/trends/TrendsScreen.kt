package com.example.healthplatform.presentation.trends

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.healthplatform.domain.model.TrendPoint

@Composable
fun TrendsScreen(
    contentPadding: PaddingValues,
    viewModel: TrendsViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val userId = "demo_user"

    LaunchedEffect(Unit) {
        viewModel.load(
            userId = userId,
            endTime = System.currentTimeMillis()
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Trends",
                style = MaterialTheme.typography.headlineSmall
            )
        }

        item {
            if (uiState.loading) {
                CircularProgressIndicator()
            }
        }

        uiState.error?.let { message ->
            item {
                Text(
                    text = message,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }

        item {
            TrendSection(title = "Recent 7-Day Steps", points = uiState.stepTrend, unit = "steps")
        }

        item {
            TrendSection(title = "Recent 7-Day Average Heart Rate", points = uiState.heartRateTrend, unit = "bpm")
        }

        item {
            TrendSection(title = "Recent 7-Day Sleep Duration", points = uiState.sleepTrend, unit = "h")
        }
    }
}

@Composable
private fun TrendSection(
    title: String,
    points: List<TrendPoint>,
    unit: String
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium
            )

            if (points.isEmpty()) {
                Text(
                    text = "No data available",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                points.forEach { point ->
                    Text(
                        text = "${point.dayLabel} : ${formatTrendValue(point.value, unit)}",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}

private fun formatTrendValue(value: Double, unit: String): String {
    return when (unit) {
        "steps" -> "${value.toInt()} $unit"
        "bpm" -> "${value.toInt()} $unit"
        else -> String.format("%.1f %s", value, unit)
    }
}
